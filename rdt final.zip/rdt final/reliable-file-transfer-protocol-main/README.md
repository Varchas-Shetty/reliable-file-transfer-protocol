# Reliable File Transfer Protocol over UDP

This project implements a **reliable and resumable file transfer system over UDP** in C using low-level socket programming. Because UDP does not provide delivery guarantees, the application adds its own reliability layer with acknowledgements, retransmissions, resume support, integrity checking, and a sliding transfer window.

The transfer session also includes **DTLS-based security** using OpenSSL, which brings SSL/TLS-style protection to the UDP session.

## Features

- UDP-based file transfer
- DTLS-secured transfer session
- Chunked file delivery
- Sliding-window reliability instead of stop-and-wait
- Resume interrupted transfers from the last completed chunk
- CRC32 integrity verification for each chunk and the final file
- Concurrent transfers using per-session UDP worker sockets

## Protocol Overview

The server uses one UDP control socket on port `8080` and creates a dedicated UDP data session for each client request.

Flow:

1. Client sends `REQUEST(filename, resume_seq)` to the server control port.
2. Server validates the file, computes metadata, opens a dedicated transfer port, and returns `SESSION_INFO`.
3. Client connects its UDP socket to the assigned transfer port.
4. Client and server perform a **DTLS handshake** on that transfer socket.
5. Client sends `START(session_id, resume_seq)` securely over DTLS.
6. Server streams file chunks using a sliding window.
7. Client sends cumulative `ACK(next_expected_seq)` messages securely over DTLS.
8. On timeout, the server retransmits unacknowledged chunks.
9. When the file completes, the server sends `END`.
10. Client verifies the final CRC32 and keeps the partially downloaded file if interrupted, allowing resume on the next run.

## Security Note

- The file-transfer session itself is protected with DTLS.
- The initial UDP discovery step on the control socket is lightweight setup logic before the DTLS session begins.

## Project Structure

```text
client/
  client.c
  client_utils.c
  include/client.h
common/
  constants.h
  protocol.c
  protocol.h
  utils.c
  utils.h
docs/
  architecture.md
  performance.md
  protocol.md
security/
  certs/
    server.crt
    server.key
  ssl_setup.c
  ssl_setup.h
server/
  connection_handler.c
  include/server.h
  server.c
  test.txt
  thread_pool.c
tests/
  performance_test.py
Makefile
README.md
```

## Build

Build from the repository root on Linux or Ubuntu WSL:

```bash
make
```

This produces:

- `server/server_app`
- `client/client_app`

## Run

Start the server:

```bash
./server/server_app
```

Download a file from the same machine:

```bash
./client/client_app test.txt
```

Download from another machine:

```bash
./client/client_app 192.168.1.10 test.txt
```

If the transfer is interrupted, simply rerun the same command. The client resumes from the last aligned chunk already written in the output file.

## Two-System Notes

- Use the **server machine's real LAN IPv4 address**.
- Do not use `127.0.0.1` for cross-system tests.
- Do not use WSL-only virtual addresses such as `172.26.x.x`.
- Run from the repository root so the certificate and relative file paths resolve correctly.

## Demo Checklist

To show the assignment requirements clearly:

1. Start the UDP server.
2. Download `server/test.txt`.
3. Use a file larger than one chunk, stop the client midway, and rerun it to show resume behavior.
4. Start multiple clients at the same time to show concurrency.
5. Show the DTLS-secured session and final CRC32 verification message on the client.

## Notes

- Files are served from the `server/` directory by default.
- Unsafe filenames such as paths with `/`, `\`, or `..` are rejected.
- The client keeps partial downloads so resume works across runs.
- `server/test.txt` is useful for a quick smoke test, but a larger file is better for demonstrating resume and throughput.
